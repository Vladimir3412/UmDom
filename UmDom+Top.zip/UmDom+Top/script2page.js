document.addEventListener("DOMContentLoaded", () => {
    const detailsElements = document.querySelectorAll(".faq details");
  
    detailsElements.forEach((details) => {
      const content = details.querySelector("p");
  
      // Изначальные стили для плавности
      content.style.height = "0";
      content.style.overflow = "hidden";
      content.style.transition = "height 0.3s ease-in-out";
  
      details.addEventListener("toggle", () => {
        if (details.open) {
          // Закрываем все остальные элементы
          detailsElements.forEach((otherDetails) => {
            if (otherDetails !== details && otherDetails.open) {
              const otherContent = otherDetails.querySelector("p");
              otherContent.style.height = `${otherContent.scrollHeight}px`;
              requestAnimationFrame(() => {
                otherContent.style.height = "0";
              });
              otherDetails.open = false;
            }
          });
  
          // Открытие текущего элемента
          content.style.height = `${content.scrollHeight}px`;
          content.addEventListener("transitionend", function resetHeight() {
            if (details.open) {
              content.style.height = "auto"; // Сброс для корректного повторного открытия
              content.removeEventListener("transitionend", resetHeight);
            }
          });
        } else {
          // Закрытие текущего элемента
          content.style.height = `${content.scrollHeight}px`;
          requestAnimationFrame(() => {
            content.style.height = "0";
          });
        }
      });
    });
  });
  